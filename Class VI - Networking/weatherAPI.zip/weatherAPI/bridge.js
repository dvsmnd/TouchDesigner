#!/usr/bin/env node
// Weather to OSC bridge
// Browsers cannot send UDP, so this tiny relay accepts OSC packets over a local
// WebSocket and forwards them as UDP to the host and port chosen in the page.
// It also serves weather-osc.html at http://localhost:8080.
// No dependencies. Needs Node 14 or newer.
//
//   node bridge.js          (port 8080)
//   node bridge.js 9000     (another port)

const http = require('http');
const crypto = require('crypto');
const dgram = require('dgram');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.argv[2] || process.env.PORT || 8080);
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_FRAME = 1 << 20;

const udp = dgram.createSocket('udp4');
udp.on('error', err => console.error('UDP error:', err.message));

// Only pages opened from this computer may use the relay.
function originOk(origin){
  if (!origin || origin === 'null') return true; // file:// pages report "null"
  try { return ['localhost', '127.0.0.1', '[::1]'].includes(new URL(origin).hostname); }
  catch (e) { return false; }
}

const server = http.createServer((req, res) => {
  if (['/', '/index.html', '/weather-osc.html'].includes(req.url.split('?')[0])){
    fs.readFile(path.join(__dirname, 'weather-osc.html'), (err, html) => {
      if (err){ res.writeHead(404); res.end('weather-osc.html must sit next to bridge.js'); return; }
      res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'}); res.end(html);
    });
  } else { res.writeHead(404); res.end('Not found'); }
});

function frame(opcode, payload){
  const len = payload.length; let head;
  if (len < 126) head = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536){ head = Buffer.alloc(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | opcode; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}
const sendJson = (conn, obj) => { if (!conn.socket.destroyed) conn.socket.write(frame(0x1, Buffer.from(JSON.stringify(obj)))); };

function onMessage(conn, opcode, buf){
  if (opcode === 0x1){ // text: control message
    let m; try { m = JSON.parse(buf.toString('utf8')); } catch (e) { return; }
    if (m.type === 'target'){
      const port = Number(m.port), host = String(m.host || '').trim();
      if (!host || !Number.isInteger(port) || port < 1 || port > 65535){ sendJson(conn, {type:'error', message:'Invalid host or port'}); return; }
      conn.target = {host, port};
      console.log(`[${conn.id}] forwarding OSC to ${host}:${port}`);
      sendJson(conn, {type:'target', host, port});
    }
  } else if (opcode === 0x2){ // binary: one OSC packet
    if (!conn.target){ sendJson(conn, {type:'error', message:'No target set'}); return; }
    udp.send(buf, 0, buf.length, conn.target.port, conn.target.host, err => {
      if (!err){ conn.sent++; return; }
      const now = Date.now();
      if (now - conn.lastErr > 2000){ conn.lastErr = now; console.error(`[${conn.id}] UDP send failed: ${err.message}`); sendJson(conn, {type:'error', message:'UDP send failed: ' + err.message}); }
    });
  }
}

function onData(conn, chunk){
  conn.buf = Buffer.concat([conn.buf, chunk]);
  for (;;){
    const b = conn.buf;
    if (b.length < 2) return;
    const fin = (b[0] & 0x80) !== 0, opcode = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0;
    let len = b[1] & 0x7f, off = 2;
    if (len === 126){ if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127){ if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
    if (len > MAX_FRAME){ conn.socket.destroy(); return; }
    const maskLen = masked ? 4 : 0;
    if (b.length < off + maskLen + len) return;
    let payload = b.subarray(off + maskLen, off + maskLen + len);
    if (masked){
      const mask = b.subarray(off, off + 4); payload = Buffer.from(payload);
      for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
    }
    conn.buf = b.subarray(off + maskLen + len);

    if (opcode === 0x0 || opcode === 0x1 || opcode === 0x2){
      if (opcode !== 0x0){ conn.fragOp = opcode; conn.frag = []; }
      if (!conn.frag) continue;
      conn.frag.push(payload);
      if (fin){ const msg = Buffer.concat(conn.frag); conn.frag = null; onMessage(conn, conn.fragOp, msg); }
    } else if (opcode === 0x8){
      conn.socket.write(frame(0x8, payload.subarray(0, 2))); conn.socket.end(); return;
    } else if (opcode === 0x9){
      conn.socket.write(frame(0xA, payload));
    }
  }
}

let nextId = 1;
server.on('upgrade', (req, socket, head) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade).toLowerCase() !== 'websocket' || !originOk(req.headers.origin)){
    socket.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return;
  }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  const conn = {id: nextId++, socket, buf: Buffer.alloc(0), frag: null, fragOp: 0, target: null, sent: 0, lastErr: 0};
  console.log(`[${conn.id}] page connected`);
  socket.on('data', chunk => onData(conn, chunk));
  socket.on('error', () => {});
  socket.on('close', () => console.log(`[${conn.id}] page disconnected after ${conn.sent} packets`));
  if (head && head.length) onData(conn, head);
});

server.on('error', err => {
  console.error(err.code === 'EADDRINUSE' ? `Port ${PORT} is already in use. Try: node bridge.js ${PORT + 1}` : err.message);
  process.exit(1);
});
server.listen(PORT, '127.0.0.1', () => {
  console.log(`Weather to OSC bridge is running.`);
  console.log(`Open http://localhost:${PORT} and press "Connect bridge".`);
});
